#define ASIG 1
#define SUMA 2
#define REST 3
#define MULT 4
#define DIVI 5
#define PARI 6
#define PARD 7
#define PRIN 8 //PRINT
#define IDEN 9
#define ENTE 10
#define PYCO 11 //PUNTO Y COMA